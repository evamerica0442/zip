@echo off
REM Spaza Shop POS - Complete Setup Script for Windows
REM Run this batch file to set up the entire project

echo.
echo ========================================
echo  Spaza Shop POS - Setup Script (Windows)
echo ========================================
echo.

REM Step 1: Check Node.js installation
echo [Step 1] Checking Node.js installation...
node --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js is not installed or not in PATH
    echo Please download from https://nodejs.org/
    pause
    exit /b 1
)
echo Node.js is installed
echo.

REM Step 2: Install dependencies
echo [Step 2] Installing dependencies...
call npm install
if errorlevel 1 (
    echo ERROR: Failed to install root dependencies
    pause
    exit /b 1
)

call npm install --workspace=backend
if errorlevel 1 (
    echo ERROR: Failed to install backend dependencies
    pause
    exit /b 1
)

call npm install --workspace=frontend
if errorlevel 1 (
    echo ERROR: Failed to install frontend dependencies
    pause
    exit /b 1
)

echo Dependencies installed successfully
echo.

REM Step 3: Set up environment files
echo [Step 3] Setting up environment files...

if not exist "backend\.env" (
    copy "backend\.env.example" "backend\.env"
    echo WARNING: Created backend\.env - Please edit with your database credentials
) else (
    echo backend\.env already exists
)

if not exist "frontend\.env" (
    copy "frontend\.env.example" "frontend\.env"
    echo Created frontend\.env
) else (
    echo frontend\.env already exists
)

echo.

REM Step 4: Database setup reminder
echo [Step 4] Database Setup Required
echo.
echo Prerequisites:
echo   1. PostgreSQL installed and running
echo   2. Create database using pgAdmin or command:
echo      psql -U postgres -c "CREATE DATABASE spaza_pos;"
echo   3. Update backend\.env with correct DB credentials
echo.

REM Step 5: Summary
echo ========================================
echo Setup Complete!
echo ========================================
echo.
echo Next Steps:
echo.
echo 1. Edit backend\.env with PostgreSQL credentials:
echo    - DB_HOST: localhost
echo    - DB_USER: postgres
echo    - DB_PASSWORD: your_password
echo    - DB_NAME: spaza_pos
echo.
echo 2. Create database (using pgAdmin or command line):
echo    psql -U postgres -c "CREATE DATABASE spaza_pos;"
echo.
echo To Start Development:
echo.
echo   Terminal 1 (Backend):
echo     cd backend
echo     npm run migrate      (initialize database)
echo     npm run dev          (start server on port 5000)
echo.
echo   Terminal 2 (Frontend):
echo     cd frontend
echo     npm run dev          (start app on port 3000)
echo.
echo Documentation:
echo   - Quick Start: QUICKSTART.md
echo   - Development: DEVELOPMENT.md
echo   - API Reference: API.md
echo   - Deployment: DEPLOYMENT.md
echo.
echo ========================================
echo.
pause
