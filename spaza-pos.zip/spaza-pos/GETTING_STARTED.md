# 🎯 Spaza Shop POS - Getting Started Visual Guide

## 📍 You Are Here

```
Your Location: c:\Users\Admin\Desktop\Projects\Projects\spaza-pos\
```

## 🚀 Start Here

### Option 1: Automatic Setup (Recommended for Windows)
```
1. Double-click: setup.bat
2. Follow on-screen instructions
3. Edit backend/.env with database credentials
4. Create PostgreSQL database
5. Run backend and frontend separately
```

### Option 2: Automatic Setup (macOS/Linux)
```bash
chmod +x setup.sh
./setup.sh
# Then follow instructions
```

### Option 3: Manual Setup (Full Control)
```bash
# Terminal 1 - Install and start backend
cd backend
cp .env.example .env
# Edit .env with your database settings
npm install
npm run migrate      # Initialize database
npm run dev          # Start on http://localhost:5000

# Terminal 2 - Install and start frontend
cd frontend
cp .env.example .env
npm install
npm run dev          # Starts on http://localhost:3000
```

---

## 🗂️ Project Structure Overview

```
spaza-pos/
│
├── 📁 backend/          ← Express API Server
│   ├── src/
│   │   ├── index.ts     ← Main server (port 5000)
│   │   ├── routes/      ← API endpoints
│   │   ├── database/    ← Database setup
│   │   └── ...
│   ├── package.json
│   └── .env             ← Database credentials (create this!)
│
├── 📁 frontend/         ← React Web App
│   ├── src/
│   │   ├── pages/       ← Login, Dashboard, POS
│   │   ├── services/    ← API client, local storage
│   │   ├── locales/     ← Translations (EN, SO, AR)
│   │   └── App.tsx      ← Main app
│   ├── package.json
│   └── .env             ← API URL (usually stays default)
│
├── 📄 README.md         ← Project overview
├── 📄 QUICKSTART.md     ← 5-minute setup
├── 📄 DEVELOPMENT.md    ← Development guide
├── 📄 DATABASE.md       ← Database setup details
├── 📄 DEPLOYMENT.md     ← Production deployment
├── 📄 API.md            ← API reference
├── 🚀 setup.bat         ← Windows setup script
├── 🚀 setup.sh          ← macOS/Linux setup script
└── ...
```

---

## ⚙️ System Architecture (Simplified)

```
┌─────────────────────────────────────────────────────────────┐
│                      WEB BROWSER                             │
│  ┌──────────────────────────────────────────────────────┐   │
│  │           React App (Port 3000)                      │   │
│  │  ┌────────────────┐        ┌────────────────────┐   │   │
│  │  │  Owner Portal  │        │  Store POS (Main)  │   │   │
│  │  │  - Register    │        │  - Products        │   │   │
│  │  │  - Create Str. │        │  - Cart            │   │   │
│  │  │  - Metrics     │        │  - Checkout        │   │   │
│  │  └────────────────┘        └────────────────────┘   │   │
│  │         All in 3 Languages (EN, SO, AR)             │   │
│  └──────────────────────────────────────────────────────┘   │
│              ↕ API Calls (JSON over HTTP)                    │
│  ┌──────────────────────────────────────────────────────┐   │
│  │    Express Server (Port 5000)                        │   │
│  │    ┌──────────────────────────────────────────────┐  │   │
│  │    │  Routes:                                     │  │   │
│  │    │  - POST /auth/owner/register                │  │   │
│  │    │  - POST /auth/owner/login                   │  │   │
│  │    │  - POST /auth/store/login                   │  │   │
│  │    │  - GET  /owner/stores                       │  │   │
│  │    │  - POST /owner/stores                       │  │   │
│  │    │  - GET  /store/products                     │  │   │
│  │    │  - POST /transactions/sync                  │  │   │
│  │    │  ... and more                               │  │   │
│  │    └──────────────────────────────────────────────┘  │   │
│  └──────────────────────────────────────────────────────┘   │
│              ↕ SQL Queries                                   │
│  ┌──────────────────────────────────────────────────────┐   │
│  │    PostgreSQL Database (Port 5432)                  │   │
│  │    Tables:                                          │   │
│  │    - owners        (owner accounts)                │   │
│  │    - stores        (individual stores)             │   │
│  │    - products      (product catalog)               │   │
│  │    - transactions  (sales records)                 │   │
│  │    - sales_metrics (daily summaries)               │   │
│  └──────────────────────────────────────────────────────┘   │
│              ↕ Local Storage (Works Offline!)                │
│  ┌──────────────────────────────────────────────────────┐   │
│  │    Browser IndexedDB                               │   │
│  │    - Products (cached locally offline)             │   │
│  │    - Transactions (queued until sync)              │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## 📱 User Experience Flow

### OWNER FLOW (5-10 minutes)
```
1. Open http://localhost:3000
   ↓
2. Click "Register" 
   ↓
3. Fill in: Email, Password, Full Name, Phone
   ↓
4. Get JWT Token (stay logged in)
   ↓
5. See Empty Dashboard
   ↓
6. Click "Create New Store"
   ↓
7. Enter: Store Name, Location, Phone
   ↓
8. Get Auto-Generated Credentials!
   Username: store-name-a1b2
   Password: abc12345
   ↓
9. Share with store staff
   ↓
10. View Metrics (30-day sales history)
```

### STORE FLOW (Day-to-Day)
```
1. Use given username & password
   ↓
2. Login at http://localhost:3000/store/login
   ↓
3. See Product List with:
   - English name
   - Somali name (if available)
   - Arabic name (if available)
   ↓
4. Search products by name or SKU
   ↓
5. Click "Add to Cart"
   ↓
6. Adjust quantities if needed
   ↓
7. Click "Checkout"
   ↓
8. Select Payment Method (Cash/Card/Mobile)
   ↓
9. Enter Customer Name (optional)
   ↓
10. Complete Transaction!
    ↓
    Saved Locally (even if offline)
    Auto-syncs to cloud in 30 minutes
```

### OFFLINE SCENARIO
```
Store is OPEN → Loading products from API
                ↓
Internet GOES DOWN → App continues working!
                     Products in browser cache
                     ↓
Staff processes sales normally (app still works!)
Transactions saved locally in IndexedDB
                ↓
Internet COMES BACK → Auto-sync triggered!
                      Transactions send to server
                      Owner sees metrics updated
```

---

## 🔑 Key Passwords & Credentials

### After Registration
```
Owner Account:
  Email:    you@example.com
  Password: yourpassword

Store Credentials: (auto-generated!)
  Username: store-name-abc123
  Password: x7y8z9w0
  
⚠️  Save store credentials! They're not recoverable!
```

---

## 🌐 Languages Supported

### In the App
```
🇺🇸 English (en)      - Default, fully translated
🇸🇴 Somali (so)       - Community focused
🇸🇦 العربية (ar)      - Full RTL support

To change: Click dropdown in top-right navbar
```

### Product Names
Each product can have names in 3 languages:
```
name_en: "Dish Soap"
name_so: "Saabuun Miidha"
name_ar: "صابون الأطباق"
```

---

## 📊 Dashboard Metrics

### What Owner Sees
```
Store: My Spaza Shop 1

Last 30 Days:
  Date          Sales      Transactions    Customers
  2024-02-07    R 5,234    45              32
  2024-02-06    R 4,890    38              28
  ...
  
Total Sales: R 45,678
```

---

## 🔄 Sync Mechanism

### How It Works
```
STORE (POS)                          SERVER
   ↓                                   ↓
Transaction ──────→ Create ────→ Pending Queue
   ↓                            ↓
Save Locally                  Wait 30 minutes
   ↓                            ↓
[OFFLINE OK]               Auto-Send Batch
   ↓                            ↓
When Online ──────→ Sync Triggered ──→ DB Updated
   ↓                                    ↓
Status: GREEN ✓                      UPDATE Dashboard
```

### Manual Sync
Button in top-right of POS:
```
Click "Sync Status" → Forces upload now
                   → Shows success/failure
                   → Updates timestamp
```

---

## 🗄️ Database Tables (What Gets Stored)

### owners
```
Email, Password (hashed), Full Name, Phone, Language
```

### stores
```
Owner ID, Store Name, Username, Password (hashed), Location, Phone
```

### products
```
Store ID, SKU, Name (EN/SO/AR), Category, Price, Stock Level
```

### transactions
```
Store ID, Date, Items (JSON), Total, Payment Method, Customer Name, Synced?
```

### sales_metrics
```
Store ID, Date, Total Sales, Transaction Count, Customer Count
```

---

## 🎨 Customization Points

### Easy to Customize
✅ Product names (add your favorite items)
✅ Store information (location, phone, email)
✅ Languages (add more in translations.json)
✅ Colors/styling (edit App.css)
✅ Payment methods (add more options)

### Medium Difficulty
⚠️ Add new fields to products
⚠️ Add customer profiles
⚠️ Add discount codes
⚠️ Add new pages/features

### Hard (Requires Backend Changes)
🔧 Add new tables to database
🔧 Change authentication system
🔧 Add reporting/analytics
🔧 Integrate payment processors

---

## 🆘 Troubleshooting Quick Links

| Problem | Solution |
|---------|----------|
| "Cannot connect to database" | Ensure PostgreSQL running, check .env credentials |
| "Port 5000/3000 already in use" | Change PORT in .env or kill process using it |
| "Module not found" | Run `npm install` in that folder |
| "Database not found" | Run `npm run migrate` in backend folder |
| "Can't access http://localhost:3000" | Ensure frontend is running (`npm run dev`) |
| "Products not loading" | Check backend is running, verify API URL in .env |
| "Transactions not syncing" | Check network, verify backend is online |

See DEVELOPMENT.md for detailed troubleshooting!

---

## 📚 Documentation Quick Reference

| File | Purpose | Read When... |
|------|---------|-------------|
| **README.md** | Overview & features | You want to understand the project |
| **QUICKSTART.md** | 5-min setup | You're setting up for first time |
| **DEVELOPMENT.md** | Development workflow | You're writing code |
| **DATABASE.md** | Database details | You need to modify database |
| **API.md** | All endpoints | You're building API clients |
| **DEPLOYMENT.md** | Production setup | You're going live |

---

## ✅ Pre-Launch Checklist

Before running the app:
- [ ] Node.js installed (run `node --version`)
- [ ] PostgreSQL installed and running
- [ ] PostgreSQL database created: `spaza_pos`
- [ ] backend/.env file created with DB credentials
- [ ] frontend/.env file exists (can be default)
- [ ] Both `npm install` completed

Before going to production:
- [ ] Change JWT_SECRET in backend/.env
- [ ] Test with real data offline and online
- [ ] Test all 3 languages (EN, SO, AR)
- [ ] Backup database regularly
- [ ] Enable HTTPS (with SSL certificate)
- [ ] Set up monitoring/logging

---

## 🎯 5-Minute Quick Start

```bash
# 1. Setup (1 min)
setup.bat              # (Windows) or ./setup.sh (Mac/Linux)

# 2. Configure (1 min)
Edit backend/.env      # Add database credentials
Create database        # PostgreSQL: CREATE DATABASE spaza_pos;

# 3. Start Backend (1 min)
cd backend
npm run migrate        # Create tables
npm run dev            # Start server

# 4. Start Frontend (1 min)
# In new terminal
cd frontend
npm run dev             # Opens http://localhost:3000

# 5. Test (1 min)
Register → Create Store → Login as Store → Test POS
```

---

## 🚀 Ready to Code?

Check Your Setup:
```bash
node --version          # Should be 16+
postgres --version      # Should be 12+
npm --version           # Should be 6+
```

Then Start Here:
1. Open DEVELOPMENT.md
2. Read "Development Workflow"
3. Make a small change to test
4. See your changes in browser

---

## 🎓 Learning Path

### Day 1: Understand
- Read README.md
- Open frontend/src/pages/POSDashboard.tsx
- See how components work together

### Day 2: Set Up
- Follow QUICKSTART.md
- Get system running locally
- Create test data

### Day 3: Explore
- Login as owner, create store
- Login as store, process transaction
- Test offline mode
- Switch languages

### Day 4+: Customize
- Add your own products
- Modify styling (App.css)
- Add translations
- Plan your features

---

## 💡 Pro Tips

### Development Tips
1. **Hot Reload**: Changes auto-reload in browser
2. **DevTools**: F12 in browser to debug
3. **IndexedDB**: Storage tab in DevTools to see local data
4. **API Debug**: Network tab shows all API calls
5. **Console Logs**: Check for errors in console

### Performance Tips
1. **Offline First**: Always load products before testing offline
2. **Clear Cache**: IndexedDB > Storage > Delete to clear local data
3. **Test Sync**: Go offline, make sales, come online, check sync
4. **Monitor DB**: Use pgAdmin to monitor database

### Security Tips
1. **Never Commit .env**: These files have secrets!
2. **Test Password Reset**: Build before deployment
3. **Use HTTPS**: Essential in production
4. **Regular Backups**: Daily backup of production database

---

## 🎉 You're All Set!

```
What You Have:
✅ Complete POS system
✅ Multi-store support
✅ 3 languages built-in
✅ Offline capability
✅ Cloud sync
✅ Full documentation

Next Steps:
→ Run setup.bat or setup.sh
→ Follow QUICKSTART.md
→ Test the system
→ Customize for your needs
→ Deploy when ready
```

---

**Happy Building! 🚀**

Questions? Check the relevant documentation file above.  
Ready to deploy? See DEPLOYMENT.md.  
Need help? Check DEVELOPMENT.md troubleshooting section.
