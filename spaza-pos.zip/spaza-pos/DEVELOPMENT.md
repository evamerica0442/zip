# Development Setup

## Quick Start

### 1. Clone and Install
```bash
git clone <repo-url>
cd spaza-pos
npm install
npm install --workspace=backend
npm install --workspace=frontend
```

### 2. Environment Setup

Create `.env` files:

**backend/.env**
```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=spaza_pos
DB_USER=postgres
DB_PASSWORD=password
JWT_SECRET=dev-secret-key-change-in-prod
NODE_ENV=development
PORT=5000
SYNC_INTERVAL=1800000
```

**frontend/.env**
```env
REACT_APP_API_BASE_URL=http://localhost:5000/api
```

### 3. Start PostgreSQL
```bash
# macOS with Homebrew
brew services start postgresql

# Ubuntu/Debian
sudo systemctl start postgresql

# Windows (PostgreSQL service)
# Services > PostgreSQL
```

### 4. Run Backend
```bash
cd backend
npm run migrate  # Initialize database
npm run dev      # Start development server
```

### 5. Run Frontend (in new terminal)
```bash
cd frontend
npm run dev
```

Access the application at `http://localhost:3000`

## Development Workflow

### Adding Features

1. Create feature branch:
```bash
git checkout -b feature/feature-name
```

2. Make changes following code style
3. Test in browser
4. Commit with descriptive message:
```bash
git commit -m "feat: description of change"
```

### Adding Database Fields

1. Update type in backend/src/types/index.ts
2. Add migration query to database/migrations.ts
3. Run migrations
4. Update API endpoints as needed

### Adding Translations

1. Add to frontend/src/locales/translations.json
2. Use in component:
```typescript
const { t } = useTranslation();
<h1>{t('path.to.key')}</h1>
```

### Code Style

Uses project defaults with:
- TypeScript strict mode
- ESLint rules (if configured)
- Prettier formatting

### Testing Backend API

Use curl, Postman, or VS Code REST Client:

```http
### Register Owner
POST http://localhost:5000/api/auth/owner/register
Content-Type: application/json

{
  "email": "test@example.com",
  "password": "password123",
  "fullName": "Test User"
}

### Owner Login
POST http://localhost:5000/api/auth/owner/login
Content-Type: application/json

{
  "email": "test@example.com",
  "password": "password123"
}

### Get Stores
GET http://localhost:5000/api/owner/stores
Authorization: Bearer {token}
```

## Debugging

### Backend
- Check console logs
- Add `console.log` statements
- Use VS Code debugger:
```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "type": "node",
      "request": "launch",
      "name": "Launch Backend",
      "program": "${workspaceFolder}/backend/src/index.ts",
      "preLaunchTask": "tsc: build",
      "outFiles": ["${workspaceFolder}/backend/dist/**/*.js"]
    }
  ]
}
```

### Frontend
- Use browser DevTools
- Check Network tab for API issues
- Use React DevTools extension
- Check IndexedDB in Storage tab

### Database
```bash
# Connect to database
psql -U postgres -d spaza_pos

# List tables
\dt

# View table schema
\d table_name

# Check data
SELECT * FROM table_name LIMIT 10;
```

## Common Issues

### Database Connection Error
```
Error: connect ECONNREFUSED 127.0.0.1:5432
```
- Ensure PostgreSQL is running
- Check credentials in .env
- Verify database exists

### Port Already in Use
```bash
# Find process on port
lsof -i :5000      # macOS/Linux
netstat -ano | findstr :5000  # Windows

# Kill process
kill -9 <pid>      # macOS/Linux
taskkill /PID <pid> /F  # Windows
```

### Frontend API Connection Issues
- Check CORS is enabled in backend
- Verify API_BASE_URL in frontend .env
- Check browser console for errors
- Verify backend is running

### IndexedDB Issues
```javascript
// Clear IndexedDB in browser console
indexedDB.deleteDatabase('POSDatabase');
location.reload();
```

## Build Optimization

### Backend
```bash
cd backend
npm run build
# Creates dist/ folder for production
```

### Frontend
```bash
cd frontend
npm run build
# Creates build/ folder
# Analyze with: npm install -S source-map-explorer
# npm run analyze
```

## Performance Monitoring

### Frontend
Add to App.tsx:
```typescript
if ('performance' in window) {
  window.addEventListener('load', () => {
    const perfData = window.performance.timing;
    const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
    console.log('Page load time: ' + pageLoadTime);
  });
}
```

### Backend
```bash
# Monitor requests
npm install morgan
# Log all HTTP requests
```

## IDE Setup

### VS Code Extensions
- TypeScript Vue Plugin
- ESLint
- Prettier
- REST Client
- PostgreSQL
- Rainbow Brackets

### Recommended Settings (settings.json)
```json
{
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "editor.codeActionsOnSave": {
    "source.fixAll.eslint": true
  }
}
```

## Next Steps

1. Explore the codebase
2. Make a small feature change
3. Test in browser
4. Review API documentation
5. Check database structure
6. Practice adding new features

## Getting Help

- Check console for errors
- Review documentation in repo
- Check code comments
- Look at similar implementations
- Test in smaller increments
