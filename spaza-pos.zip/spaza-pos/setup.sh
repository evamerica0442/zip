#!/bin/bash

# Spaza Shop POS - Complete Setup Script
# Run this script to set up the entire project

set -e  # Exit on any error

echo "🚀 Spaza Shop POS - Complete Setup Script"
echo "=========================================="
echo ""

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Step 1: Install Node Dependencies
echo -e "${BLUE}Step 1: Installing Node Dependencies...${NC}"
npm install

echo -e "${BLUE}Installing Backend Dependencies...${NC}"
npm install --workspace=backend

echo -e "${BLUE}Installing Frontend Dependencies...${NC}"
npm install --workspace=frontend

echo -e "${GREEN}✓ Dependencies installed${NC}"
echo ""

# Step 2: Set up environment files
echo -e "${BLUE}Step 2: Setting up Environment Files...${NC}"

if [ ! -f "backend/.env" ]; then
    cp backend/.env.example backend/.env
    echo -e "${YELLOW}⚠️  Created backend/.env - Please edit with your database credentials${NC}"
else
    echo -e "${GREEN}✓ backend/.env already exists${NC}"
fi

if [ ! -f "frontend/.env" ]; then
    cp frontend/.env.example frontend/.env
    echo -e "${GREEN}✓ Created frontend/.env${NC}"
else
    echo -e "${GREEN}✓ frontend/.env already exists${NC}"
fi

echo ""

# Step 3: Database setup reminder
echo -e "${BLUE}Step 3: Database Setup${NC}"
echo -e "${YELLOW}Prerequisites:${NC}"
echo "  1. PostgreSQL installed and running"
echo "  2. Create database: psql -U postgres -c \"CREATE DATABASE spaza_pos;\""
echo "  3. Update backend/.env with correct DB credentials"
echo ""

# Step 4: Summary
echo -e "${GREEN}=========================================="
echo "✓ Setup Complete!${NC}"
echo ""
echo -e "${BLUE}Next Steps:${NC}"
echo "1. Edit backend/.env with your PostgreSQL credentials"
echo "2. Create database: psql -U postgres -c \"CREATE DATABASE spaza_pos;\""
echo ""
echo -e "${YELLOW}To Start Development:${NC}"
echo ""
echo "  Terminal 1 (Backend):"
echo "    cd backend"
echo "    npm run migrate      # Initialize database"
echo "    npm run dev          # Start server on port 5000"
echo ""
echo "  Terminal 2 (Frontend):"
echo "    cd frontend"
echo "    npm run dev          # Start app on port 3000"
echo ""
echo -e "${BLUE}Documentation:${NC}"
echo "  - Setup: QUICKSTART.md"
echo "  - Development: DEVELOPMENT.md"
echo "  - API: API.md"
echo "  - Deployment: DEPLOYMENT.md"
echo ""
echo "=========================================="
