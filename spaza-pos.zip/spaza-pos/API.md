# API Reference

## Base URL
```
http://localhost:5000/api
```

## Authentication
All protected routes require a Bearer token in the Authorization header:
```
Authorization: Bearer <token>
```

---

## Authentication Endpoints

### Register Owner
```
POST /auth/owner/register
Content-Type: application/json

{
  "email": "owner@example.com",
  "password": "securepassword",
  "fullName": "John Doe",
  "phone": "+27712345678",
  "preferredLanguage": "en"
}

Response (201):
{
  "owner": {
    "id": "uuid",
    "email": "owner@example.com",
    "full_name": "John Doe"
  },
  "token": "jwt_token",
  "message": "Owner registered successfully"
}
```

### Login Owner
```
POST /auth/owner/login
Content-Type: application/json

{
  "email": "owner@example.com",
  "password": "securepassword"
}

Response (200):
{
  "owner": {
    "id": "uuid",
    "email": "owner@example.com",
    "full_name": "John Doe"
  },
  "token": "jwt_token"
}
```

### Login Store
```
POST /auth/store/login
Content-Type: application/json

{
  "username": "store-username",
  "password": "store-password"
}

Response (200):
{
  "store": {
    "id": "uuid",
    "name": "Store Name"
  },
  "token": "jwt_token"
}
```

---

## Owner Endpoints

### Get All Stores
```
GET /owner/stores
Authorization: Bearer <owner_token>

Response (200):
[
  {
    "id": "uuid",
    "store_name": "Spaza Shop 1",
    "store_username": "spaza-shop-1-a1b2",
    "location": "Soweto",
    "phone": "+27712345678",
    "email": "store@example.com",
    "is_active": true,
    "created_at": "2024-01-15T10:30:00Z"
  }
]
```

### Create Store
```
POST /owner/stores
Authorization: Bearer <owner_token>
Content-Type: application/json

{
  "storeName": "Spaza Shop 1",
  "location": "Soweto",
  "phone": "+27712345678",
  "email": "store@example.com"
}

Response (201):
{
  "store": {
    "id": "uuid",
    "store_name": "Spaza Shop 1",
    "store_username": "spaza-shop-1-a1b2",
    "location": "Soweto",
    "phone": "+27712345678",
    "email": "store@example.com",
    "is_active": true
  },
  "credentials": {
    "username": "spaza-shop-1-a1b2",
    "password": "abc12345",
    "message": "Save these credentials securely. Password will not be shown again."
  }
}
```

### Get Store Metrics
```
GET /owner/metrics/:storeId
Authorization: Bearer <owner_token>

Response (200):
{
  "metrics": [
    {
      "date": "2024-01-15",
      "total_sales": 5000.00,
      "total_transactions": 25,
      "unique_customers": 18
    }
  ],
  "totalSales": 45000.00
}
```

---

## Store Endpoints

### Get Products
```
GET /store/products
Authorization: Bearer <store_token>

Response (200):
[
  {
    "id": "uuid",
    "sku": "SOAP-001",
    "name_en": "Dish Soap",
    "name_so": "Saabuun Miidha",
    "name_ar": "صابون الأطباق",
    "category": "Cleaning",
    "price": 50.00,
    "quantity_in_stock": 120
  }
]
```

### Add/Update Product
```
POST /store/products
Authorization: Bearer <store_token>
Content-Type: application/json

{
  "sku": "SOAP-001",
  "nameEn": "Dish Soap",
  "nameSo": "Saabuun Miidha",
  "nameAr": "صابون الأطباق",
  "category": "Cleaning",
  "price": 50.00,
  "reorderLevel": 10
}

Response (201):
{
  "id": "uuid",
  "sku": "SOAP-001",
  "name_en": "Dish Soap",
  "name_so": "Saabuun Miidha",
  "name_ar": "صابون الأطباق",
  "price": 50.00
}
```

### Get Store Info
```
GET /store/info
Authorization: Bearer <store_token>

Response (200):
{
  "id": "uuid",
  "store_name": "Spaza Shop 1",
  "location": "Soweto",
  "phone": "+27712345678",
  "email": "store@example.com"
}
```

---

## Transaction Endpoints

### Sync Transactions
```
POST /transactions/sync
Authorization: Bearer <store_token>
Content-Type: application/json

{
  "transactions": [
    {
      "id": "uuid",
      "transaction_date": "2024-01-15T14:30:00Z",
      "items": [
        {
          "product_id": "uuid",
          "product_name": "Dish Soap",
          "quantity": 2,
          "unit_price": 50.00,
          "total": 100.00
        }
      ],
      "total_amount": 100.00,
      "payment_method": "cash",
      "customer_name": "John Doe"
    }
  ]
}

Response (200):
{
  "synced": 1,
  "message": "Transactions synced successfully"
}
```

### Get Pending Transactions
```
GET /transactions/pending
Authorization: Bearer <store_token>

Response (200):
[
  {
    "id": "uuid",
    "transaction_date": "2024-01-15T14:30:00Z",
    "items": [...],
    "total_amount": 100.00,
    "payment_method": "cash",
    "customer_name": "John Doe"
  }
]
```

---

## Error Responses

### 400 Bad Request
```json
{
  "error": "Missing required fields"
}
```

### 401 Unauthorized
```json
{
  "error": "Invalid credentials"
}
```

### 403 Forbidden
```json
{
  "error": "Unauthorized"
}
```

### 409 Conflict
```json
{
  "error": "Email already registered"
}
```

### 500 Internal Server Error
```json
{
  "error": "Internal server error"
}
```

---

## Rate Limiting

Currently no rate limiting implemented. Consider adding:
- 100 requests per minute per IP
- 10 requests per second per user
- Custom limits by endpoint

---

## Pagination

Currently all endpoints return full results. Consider adding:
- `?page=1&limit=20` query parameters
- `X-Total-Count` response header
- `X-Page-Count` response header

---

## Webhooks (Future)

Planned webhook events:
- `transaction.completed`
- `inventory.low`
- `sync.failed`
- `store.created`

---

## SDK/Client Library (Future)

Consider creating official SDKs for:
- Python
- JavaScript/Node.js
- Mobile (Flutter/React Native)
