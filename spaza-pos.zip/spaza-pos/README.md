# Spaza Shop POS System

A comprehensive, multi-language Point of Sale (POS) system designed for spaza shops in South Africa with support for Somali, English, and Arabic communities.

## 🎯 Features

### Owner Portal
- **Multi-Store Management**: Register once, create and manage multiple stores
- **Sales Dashboard**: View real-time sales metrics for each store
- **Store Credentials**: Generate unique username/password for each store
- **Analytics**: 30-day sales tracking with transaction counts

### Store POS Interface
- **Offline-First Architecture**: Works seamlessly without internet connection
- **Local Data Storage**: IndexedDB for product catalog and transactions
- **Automatic Cloud Sync**: Every 30 minutes or on-demand
- **Multi-Language Support**: Somali, English, and Arabic with RTL support
- **Cart Management**: Add, edit, remove items with real-time calculations
- **Multiple Payment Methods**: Cash, Card, Mobile Money
- **Transaction History**: Local storage of all transactions

### Technical Highlights
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Progressive Enhancement**: Fallback to local data when offline
- **JWT Authentication**: Secure token-based authentication
- **Database Sync**: Intelligent sync mechanism with retry logic
- **Multi-language Database**: Product names in multiple languages
- **RTL Support**: Full right-to-left interface support for Arabic

## 📋 System Requirements

### Backend
- Node.js 16+ 
- PostgreSQL 12+
- npm or yarn

### Frontend
- Modern web browser with JavaScript enabled
- IndexedDB support (for offline functionality)

## 🚀 Getting Started

### 1. Backend Setup

```bash
cd backend
cp .env.example .env
# Edit .env with your database credentials
npm install
npm run migrate
npm run dev
```

### 2. Frontend Setup

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

The application will be available at `http://localhost:3000`

## 📱 Usage Flow

### For Owners:
1. Register at `/owner/register`
2. Create stores from the dashboard
3. Share store credentials (username/password) with store staff
4. Monitor sales metrics from the owner dashboard

### For Store Staff:
1. Login with store credentials at `/store/login`
2. Use POS interface to ring up sales
3. Complete transactions offline or online
4. System automatically syncs every 30 minutes

## 🌍 Supported Languages

- **English (en)** - Default language
- **Somali (so)** - Community-focused translations
- **Arabic (ar)** - Full RTL interface support

Language selection is persistent and stored locally in the browser.

## 📊 Database Schema

### Tables
- `owners` - Store owner accounts
- `stores` - Individual store information
- `products` - Product catalog with multi-language names
- `transactions` - Sales transactions with sync status
- `sales_metrics` - Aggregated daily metrics

## 🔐 Security Features

- Password hashing with bcryptjs
- JWT token-based authentication
- Secure password reset flow
- Store-specific database access control

## 🔄 Sync Mechanism

Transactions are automatically synced to the cloud every 30 minutes:
- Pending transactions stored in IndexedDB
- Automatic retry on failure
- Manual sync option available
- Sync status indicator in UI

## 📦 Local Storage Structure (IndexedDB)

```json
{
  "products": {
    "sku": "string (primary key)",
    "name_en": "string",
    "name_so": "string",
    "name_ar": "string",
    "price": "number",
    "quantity_in_stock": "number"
  },
  "transactions": {
    "id": "string (primary key)",
    "transaction_date": "date",
    "items": "array",
    "total_amount": "number",
    "synced": "boolean"
  }
}
```

## 🎨 Culturally-Tailored UX Features

1. **Large Touch Buttons**: Optimized for store environment with fingers/gloves
2. **High Contrast Colors**: Easy to read in various lighting conditions
3. **Simple Navigation**: Minimal steps to complete transactions
4. **Community Languages**: Full native language support
5. **Offline Reliability**: Core functionality works without internet
6. **Clear Feedback**: Transaction confirmations and status updates
7. **Fast Loading**: Static assets cache for quick startup

## 📞 Support for Target Communities

### Somalian Community
- Full Somali language interface
- Somali product names support
- Common Somali payment method support

### Nigerian Community
- English language support (widely spoken)
- Common product categories for Nigerian spazas
- Mobile money integration

### Pakistani Community
- English and Urdu-compatible interface
- Halal product categorization support
- Common Pakistani payment methods

## 🛠️ Development

### Project Structure

```
spaza-pos/
├── backend/                 # Express API
│   ├── src/
│   │   ├── index.ts        # Main server
│   │   ├── routes/         # API endpoints
│   │   ├── controllers/    # Business logic
│   │   ├── middleware/     # Auth & validation
│   │   ├── database/       # Database setup
│   │   ├── utils/          # Helper functions
│   │   └── types/          # TypeScript types
│   ├── package.json
│   └── tsconfig.json
│
├── frontend/                # React SPA
│   ├── src/
│   │   ├── pages/          # Page components
│   │   ├── components/     # Reusable components
│   │   ├── services/       # API & Database services
│   │   ├── store/          # Zustand stores
│   │   ├── hooks/          # Custom hooks
│   │   ├── locales/        # i18n translations
│   │   ├── App.tsx         # Main app component
│   │   └── index.tsx       # Entry point
│   ├── public/
│   ├── package.json
│   └── tsconfig.json
│
├── shared/                  # Shared utilities
└── README.md
```

## 🚀 Deployment

### Backend Deployment (Railway, Heroku, etc.)
1. Set environment variables
2. Run database migrations
3. Deploy Node.js application
4. Ensure PostgreSQL database is accessible

### Frontend Deployment (Vercel, Netlify, etc.)
1. Set `REACT_APP_API_BASE_URL` environment variable
2. Build: `npm run build`
3. Deploy `build` folder

## 📝 API Documentation

### Authentication Endpoints
- `POST /api/auth/owner/register` - Register new owner
- `POST /api/auth/owner/login` - Owner login
- `POST /api/auth/store/login` - Store login

### Owner Endpoints
- `GET /api/owner/stores` - Get owner's stores
- `POST /api/owner/stores` - Create new store
- `GET /api/owner/metrics/:storeId` - Get store metrics

### Store Endpoints
- `GET /api/store/products` - Get products
- `POST /api/store/products` - Add/update product
- `GET /api/store/info` - Get store info

### Transaction Endpoints
- `POST /api/transactions/sync` - Sync transactions
- `GET /api/transactions/pending` - Get pending transactions

## 🐛 Troubleshooting

### Sync Issues
- Check network connection
- Verify API endpoint in `.env`
- Check browser console for errors
- Try manual sync from UI

### Offline Mode
- Ensure products are loaded before going offline
- Transactions will be queued locally
- Sync occurs automatically when online

### Database Connection
- Verify PostgreSQL is running
- Check database credentials in `.env`
- Ensure JWT_SECRET is set

## 📄 License

This project is designed for spaza shop owners in South Africa and communities worldwide.

## 🤝 Contributing

Contributions are welcome! Please help improve accessibility for the target communities.

## 📞 Support

For issues or feature requests, please contact the development team.
