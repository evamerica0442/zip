import express, { Express, Request, Response, NextFunction } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { Pool } from 'pg';
import authRoutes from './routes/auth';
import ownerRoutes from './routes/owner';
import storeRoutes from './routes/store';
import transactionRoutes from './routes/transactions';
import authMiddleware from './middleware/auth';

dotenv.config();

const app: Express = express();
const port = process.env.PORT || 5000;

// Global database pool
export const db = new Pool({
  host: process.env.DB_HOST,
  port: parseInt(process.env.DB_PORT || '5432'),
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});

// Middleware
app.use(cors());
app.use(express.json());

// Health check
app.get('/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date() });
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/owner', authMiddleware, ownerRoutes);
app.use('/api/store', authMiddleware, storeRoutes);
app.use('/api/transactions', authMiddleware, transactionRoutes);

// Error handling middleware
app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  console.error(err);
  res.status(err.status || 500).json({
    error: err.message || 'Internal server error',
  });
});

// Start server
app.listen(port, () => {
  console.log(`🚀 Server running on port ${port}`);
  console.log(`✅ Database connection pool created`);
});

export default app;
