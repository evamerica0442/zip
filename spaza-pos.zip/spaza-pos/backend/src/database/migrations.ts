import { Pool } from 'pg';

const db = new Pool({
  host: process.env.DB_HOST,
  port: parseInt(process.env.DB_PORT || '5432'),
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});

export async function initializeDatabase() {
  const client = await db.connect();
  try {
    // Owners table
    await client.query(`
      CREATE TABLE IF NOT EXISTS owners (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        full_name VARCHAR(255) NOT NULL,
        phone VARCHAR(20),
        preferred_language VARCHAR(10) DEFAULT 'en',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Stores table
    await client.query(`
      CREATE TABLE IF NOT EXISTS stores (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        owner_id UUID NOT NULL,
        store_name VARCHAR(255) NOT NULL,
        store_username VARCHAR(255) UNIQUE NOT NULL,
        store_password_hash VARCHAR(255) NOT NULL,
        location VARCHAR(255),
        phone VARCHAR(20),
        email VARCHAR(255),
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(owner_id) REFERENCES owners(id) ON DELETE CASCADE
      )
    `);

    // Products table
    await client.query(`
      CREATE TABLE IF NOT EXISTS products (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        store_id UUID NOT NULL,
        sku VARCHAR(255) UNIQUE NOT NULL,
        name_en VARCHAR(255) NOT NULL,
        name_so VARCHAR(255),
        name_ar VARCHAR(255),
        description TEXT,
        category VARCHAR(100),
        price DECIMAL(10, 2) NOT NULL,
        quantity_in_stock INT DEFAULT 0,
        reorder_level INT DEFAULT 5,
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(store_id) REFERENCES stores(id) ON DELETE CASCADE
      )
    `);

    // Transactions table (for local sync)
    await client.query(`
      CREATE TABLE IF NOT EXISTS transactions (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        store_id UUID NOT NULL,
        transaction_date TIMESTAMP NOT NULL,
        items JSONB NOT NULL,
        total_amount DECIMAL(12, 2) NOT NULL,
        payment_method VARCHAR(50),
        customer_name VARCHAR(255),
        synced BOOLEAN DEFAULT false,
        synced_at TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(store_id) REFERENCES stores(id) ON DELETE CASCADE
      )
    `);

    // Sales metrics (for dashboard)
    await client.query(`
      CREATE TABLE IF NOT EXISTS sales_metrics (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        store_id UUID NOT NULL,
        date DATE NOT NULL,
        total_sales DECIMAL(12, 2) DEFAULT 0,
        total_transactions INT DEFAULT 0,
        unique_customers INT DEFAULT 0,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(store_id, date),
        FOREIGN KEY(store_id) REFERENCES stores(id) ON DELETE CASCADE
      )
    `);

    console.log('✅ Database initialized successfully');
  } catch (error) {
    console.error('❌ Database initialization failed:', error);
  } finally {
    client.release();
  }
}

export { db };
