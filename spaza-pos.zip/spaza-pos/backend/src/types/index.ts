export interface Owner {
  id: string;
  email: string;
  full_name: string;
  phone?: string;
  preferred_language: 'en' | 'so' | 'ar';
  created_at: Date;
}

export interface Store {
  id: string;
  owner_id: string;
  store_name: string;
  store_username: string;
  location?: string;
  phone?: string;
  email?: string;
  is_active: boolean;
}

export interface Product {
  id: string;
  store_id: string;
  sku: string;
  name_en: string;
  name_so?: string;
  name_ar?: string;
  description?: string;
  category?: string;
  price: number;
  quantity_in_stock: number;
  reorder_level: number;
  is_active: boolean;
}

export interface Transaction {
  id: string;
  store_id: string;
  transaction_date: Date;
  items: TransactionItem[];
  total_amount: number;
  payment_method?: string;
  customer_name?: string;
  synced: boolean;
}

export interface TransactionItem {
  product_id: string;
  product_name: string;
  quantity: number;
  unit_price: number;
  total: number;
}

export interface SalesMetrics {
  store_id: string;
  date: Date;
  total_sales: number;
  total_transactions: number;
  unique_customers: number;
}
