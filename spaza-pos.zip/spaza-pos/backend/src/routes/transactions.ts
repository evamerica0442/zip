import express, { Request, Response } from 'express';
import { db } from '../index';
import { v4 as uuidv4 } from 'uuid';

const router = express.Router();

interface AuthRequest extends Request {
  user?: any;
}

// Sync transactions from POS
router.post('/sync', async (req: AuthRequest, res: Response) => {
  try {
    const storeId = req.user?.id;
    const { transactions } = req.body;

    if (req.user?.type !== 'store') {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    if (!Array.isArray(transactions) || transactions.length === 0) {
      return res.status(400).json({ error: 'No transactions to sync' });
    }

    // Insert transactions
    for (const tx of transactions) {
      await db.query(
        `INSERT INTO transactions (id, store_id, transaction_date, items, total_amount, payment_method, customer_name, synced, synced_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
        [
          tx.id || uuidv4(),
          storeId,
          new Date(tx.transaction_date),
          JSON.stringify(tx.items),
          tx.total_amount,
          tx.payment_method,
          tx.customer_name,
          true,
          new Date(),
        ]
      );
    }

    // Update sales metrics
    const today = new Date().toISOString().split('T')[0];
    const metricsResult = await db.query(
      `SELECT total_sales, total_transactions FROM sales_metrics WHERE store_id = $1 AND date = $2`,
      [storeId, today]
    );

    const totalAmount = transactions.reduce((sum, tx) => sum + tx.total_amount, 0);

    if (metricsResult.rows.length > 0) {
      await db.query(
        `UPDATE sales_metrics SET total_sales = total_sales + $1, total_transactions = total_transactions + $2, updated_at = CURRENT_TIMESTAMP
         WHERE store_id = $3 AND date = $4`,
        [totalAmount, transactions.length, storeId, today]
      );
    } else {
      await db.query(
        `INSERT INTO sales_metrics (store_id, date, total_sales, total_transactions)
         VALUES ($1, $2, $3, $4)`,
        [storeId, today, totalAmount, transactions.length]
      );
    }

    res.json({ synced: transactions.length, message: 'Transactions synced successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to sync transactions' });
  }
});

// Get pending transactions
router.get('/pending', async (req: AuthRequest, res: Response) => {
  try {
    const storeId = req.user?.id;

    if (req.user?.type !== 'store') {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    const result = await db.query(
      `SELECT id, transaction_date, items, total_amount, payment_method, customer_name
       FROM transactions WHERE store_id = $1 AND synced = false`,
      [storeId]
    );

    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch pending transactions' });
  }
});

export default router;
