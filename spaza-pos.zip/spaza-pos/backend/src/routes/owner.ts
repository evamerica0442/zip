import express, { Request, Response } from 'express';
import { db } from '../index';
import { hashPassword, generateStorePassword } from '../utils/auth';
import { v4 as uuidv4 } from 'uuid';

const router = express.Router();

interface AuthRequest extends Request {
  user?: any;
}

// Get owner's stores
router.get('/stores', async (req: AuthRequest, res: Response) => {
  try {
    const ownerId = req.user?.id;

    if (req.user?.type !== 'owner') {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    const result = await db.query(
      `SELECT id, store_name, store_username, location, phone, email, is_active, created_at
       FROM stores WHERE owner_id = $1 ORDER BY created_at DESC`,
      [ownerId]
    );

    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch stores' });
  }
});

// Create new store
router.post('/stores', async (req: AuthRequest, res: Response) => {
  try {
    const { storeName, location, phone, email } = req.body;
    const ownerId = req.user?.id;

    if (req.user?.type !== 'owner') {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    if (!storeName) {
      return res.status(400).json({ error: 'Store name is required' });
    }

    const storeUsername = storeName.toLowerCase().replace(/\s+/g, '-') + '-' + uuidv4().substring(0, 4);
    const storePassword = generateStorePassword();
    const passwordHash = await hashPassword(storePassword);

    const result = await db.query(
      `INSERT INTO stores (owner_id, store_name, store_username, store_password_hash, location, phone, email)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING id, store_name, store_username, location, phone, email, is_active`,
      [ownerId, storeName, storeUsername, passwordHash, location || null, phone || null, email || null]
    );

    const store = result.rows[0];

    res.json({
      store,
      credentials: {
        username: storeUsername,
        password: storePassword,
        message: 'Save these credentials securely. Password will not be shown again.',
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to create store' });
  }
});

// Get store metrics
router.get('/metrics/:storeId', async (req: AuthRequest, res: Response) => {
  try {
    const { storeId } = req.params;
    const ownerId = req.user?.id;

    if (req.user?.type !== 'owner') {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    // Verify store belongs to owner
    const storeCheck = await db.query('SELECT owner_id FROM stores WHERE id = $1', [storeId]);
    if (storeCheck.rows.length === 0 || storeCheck.rows[0].owner_id !== ownerId) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    // Get metrics for last 30 days
    const result = await db.query(
      `SELECT date, total_sales, total_transactions, unique_customers
       FROM sales_metrics
       WHERE store_id = $1 AND date >= CURRENT_DATE - INTERVAL '30 days'
       ORDER BY date DESC`,
      [storeId]
    );

    const totalSalesResult = await db.query(
      `SELECT SUM(total_amount) as total FROM transactions WHERE store_id = $1 AND synced = true`,
      [storeId]
    );

    res.json({
      metrics: result.rows,
      totalSales: totalSalesResult.rows[0]?.total || 0,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch metrics' });
  }
});

export default router;
