import express, { Request, Response } from 'express';
import { db } from '../index';

const router = express.Router();

interface AuthRequest extends Request {
  user?: any;
}

// Get products for store
router.get('/products', async (req: AuthRequest, res: Response) => {
  try {
    const storeId = req.user?.id;

    if (req.user?.type !== 'store') {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    const result = await db.query(
      `SELECT id, sku, name_en, name_so, name_ar, category, price, quantity_in_stock
       FROM products WHERE store_id = $1 AND is_active = true
       ORDER BY category, name_en`,
      [storeId]
    );

    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

// Add/Update product
router.post('/products', async (req: AuthRequest, res: Response) => {
  try {
    const storeId = req.user?.id;
    const { sku, nameEn, nameSo, nameAr, category, price, reorderLevel } = req.body;

    if (req.user?.type !== 'store') {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    if (!sku || !nameEn || !price) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const result = await db.query(
      `INSERT INTO products (store_id, sku, name_en, name_so, name_ar, category, price, reorder_level)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       ON CONFLICT (sku) DO UPDATE SET
         name_en = $3, name_so = $4, name_ar = $5, category = $6, price = $7, reorder_level = $8
       RETURNING id, sku, name_en, name_so, name_ar, price`,
      [storeId, sku, nameEn, nameSo, nameAr, category, price, reorderLevel || 5]
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to save product' });
  }
});

// Get store info
router.get('/info', async (req: AuthRequest, res: Response) => {
  try {
    const storeId = req.user?.id;

    if (req.user?.type !== 'store') {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    const result = await db.query(
      `SELECT id, store_name, location, phone, email FROM stores WHERE id = $1`,
      [storeId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Store not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch store info' });
  }
});

export default router;
