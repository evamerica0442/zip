import express, { Request, Response } from 'express';
import { db } from '../index';
import { hashPassword, verifyPassword, generateToken, generateStorePassword } from '../utils/auth';

const router = express.Router();

// Owner registration
router.post('/owner/register', async (req: Request, res: Response) => {
  try {
    const { email, password, fullName, phone, preferredLanguage } = req.body;

    // Validate input
    if (!email || !password || !fullName) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Check if email exists
    const existingOwner = await db.query('SELECT id FROM owners WHERE email = $1', [email]);
    if (existingOwner.rows.length > 0) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    // Hash password and create owner
    const passwordHash = await hashPassword(password);
    const result = await db.query(
      `INSERT INTO owners (email, password_hash, full_name, phone, preferred_language)
       VALUES ($1, $2, $3, $4, $5) RETURNING id, email, full_name`,
      [email, passwordHash, fullName, phone || null, preferredLanguage || 'en']
    );

    const owner = result.rows[0];
    const token = generateToken({ id: owner.id, type: 'owner' });

    res.json({ owner, token, message: 'Owner registered successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// Owner login
router.post('/owner/login', async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Missing credentials' });
    }

    const result = await db.query('SELECT id, password_hash, full_name, email FROM owners WHERE email = $1', [
      email,
    ]);

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const owner = result.rows[0];
    const passwordMatch = await verifyPassword(password, owner.password_hash);

    if (!passwordMatch) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = generateToken({ id: owner.id, type: 'owner' });

    res.json({ owner: { id: owner.id, email: owner.email, full_name: owner.full_name }, token });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Login failed' });
  }
});

// Store login
router.post('/store/login', async (req: Request, res: Response) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: 'Missing credentials' });
    }

    const result = await db.query(
      'SELECT id, store_name, store_username, store_password_hash, owner_id FROM stores WHERE store_username = $1 AND is_active = true',
      [username]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const store = result.rows[0];
    const passwordMatch = await verifyPassword(password, store.store_password_hash);

    if (!passwordMatch) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = generateToken({ id: store.id, type: 'store', owner_id: store.owner_id });

    res.json({
      store: { id: store.id, name: store.store_name },
      token,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Login failed' });
  }
});

export default router;
