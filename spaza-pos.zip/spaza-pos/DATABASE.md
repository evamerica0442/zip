# Database Setup Guide

## Prerequisites

- PostgreSQL 12 or higher
- Node.js 16 or higher

## Initial Setup

### 1. Create Database

```sql
CREATE DATABASE spaza_pos;
```

### 2. Set Environment Variables

Create `.env` in the backend directory:

```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=spaza_pos
DB_USER=postgres
DB_PASSWORD=your_password
JWT_SECRET=your-super-secret-key-change-in-production
NODE_ENV=development
PORT=5000
SYNC_INTERVAL=1800000
```

### 3. Run Migrations

```bash
cd backend
npm install
npm run migrate
```

This will automatically create all required tables:
- `owners` - Store owner accounts
- `stores` - Store information and credentials
- `products` - Product catalog
- `transactions` - Sales transactions
- `sales_metrics` - Daily aggregated metrics

## Database Schema

### owners
```sql
id (UUID, PK)
email (VARCHAR, UNIQUE)
password_hash (VARCHAR)
full_name (VARCHAR)
phone (VARCHAR)
preferred_language (VARCHAR)
created_at (TIMESTAMP)
updated_at (TIMESTAMP)
```

### stores
```sql
id (UUID, PK)
owner_id (UUID, FK -> owners)
store_name (VARCHAR)
store_username (VARCHAR, UNIQUE)
store_password_hash (VARCHAR)
location (VARCHAR)
phone (VARCHAR)
email (VARCHAR)
is_active (BOOLEAN)
created_at (TIMESTAMP)
updated_at (TIMESTAMP)
```

### products
```sql
id (UUID, PK)
store_id (UUID, FK -> stores)
sku (VARCHAR, UNIQUE)
name_en (VARCHAR)
name_so (VARCHAR)
name_ar (VARCHAR)
description (TEXT)
category (VARCHAR)
price (DECIMAL)
quantity_in_stock (INT)
reorder_level (INT)
is_active (BOOLEAN)
created_at (TIMESTAMP)
updated_at (TIMESTAMP)
```

### transactions
```sql
id (UUID, PK)
store_id (UUID, FK -> stores)
transaction_date (TIMESTAMP)
items (JSONB)
total_amount (DECIMAL)
payment_method (VARCHAR)
customer_name (VARCHAR)
synced (BOOLEAN)
synced_at (TIMESTAMP)
created_at (TIMESTAMP)
```

### sales_metrics
```sql
id (UUID, PK)
store_id (UUID, FK -> stores)
date (DATE)
total_sales (DECIMAL)
total_transactions (INT)
unique_customers (INT)
updated_at (TIMESTAMP)
UNIQUE(store_id, date)
```

## Backup and Restore

### Backup Database
```bash
pg_dump -U postgres -h localhost spaza_pos > spaza_pos_backup.sql
```

### Restore Database
```bash
psql -U postgres -h localhost spaza_pos < spaza_pos_backup.sql
```

## Maintenance

### Create Indexes for Performance
```sql
CREATE INDEX idx_stores_owner_id ON stores(owner_id);
CREATE INDEX idx_transactions_store_id ON transactions(store_id);
CREATE INDEX idx_transactions_synced ON transactions(synced);
CREATE INDEX idx_products_store_id ON products(store_id);
CREATE INDEX idx_sales_metrics_store_date ON sales_metrics(store_id, date);
```

### Monitor Database Size
```sql
SELECT
  schemaname,
  tablename,
  pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) AS size
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
```

## Troubleshooting

### Connection Issues
- Ensure PostgreSQL service is running
- Check firewall rules
- Verify credentials in .env

### Migration Failures
- Check if database exists
- Verify user permissions
- Review migration error messages in console

### Performance Issues
- Run `ANALYZE` command to update statistics
- Check indexes are created
- Monitor active connections
