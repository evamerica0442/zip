import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { storeService, transactionService } from '../services/api';
import { useAuthStore, useCartStore } from '../store';
import { db } from '../services/database';
import { useSyncTransactions } from '../hooks/useSyncTransactions';
import { v4 as uuidv4 } from 'uuid';

const POSDashboard = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { logout, user } = useAuthStore();
  const cartStore = useCartStore();
  const { lastSync, isSyncing, syncNow } = useSyncTransactions();

  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showCheckout, setShowCheckout] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [customerName, setCustomerName] = useState('');

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const response = await storeService.getProducts();
      // Store products in IndexedDB for offline access
      await Promise.all(
        response.data.map((product: any) =>
          db.products.put({
            sku: product.sku,
            ...product,
          })
        )
      );
      setProducts(response.data);
    } catch (error) {
      console.error('Failed to fetch products:', error);
      // Fall back to local database
      const localProducts = await db.products.toArray();
      setProducts(localProducts as any);
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = (product: any) => {
    cartStore.addItem({
      product_id: product.id,
      product_name: product.name_en,
      quantity: 1,
      unit_price: product.price,
    });
  };

  const handleCheckout = async () => {
    try {
      const transaction = {
        id: uuidv4(),
        transaction_date: new Date(),
        items: cartStore.items,
        total_amount: cartStore.total(),
        payment_method: paymentMethod,
        customer_name: customerName,
        synced: false,
      };

      // Save to local database
      await db.transactions.add(transaction as any);

      // Try to sync immediately
      try {
        await transactionService.syncTransactions([transaction]);
      } catch (error) {
        // If sync fails, it will be retried in 30 minutes
        console.log('Will sync later');
      }

      // Clear cart and reset form
      cartStore.clear();
      setCustomerName('');
      setPaymentMethod('cash');
      setShowCheckout(false);

      alert(`Transaction #${transaction.id.substring(0, 8)} completed!`);
    } catch (error) {
      console.error('Checkout failed:', error);
    }
  };

  const filteredProducts = products.filter((product) =>
    product.name_en.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.sku.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleLogout = () => {
    logout();
    navigate('/store/login');
  };

  return (
    <div className="container pos-container">
      <div className="pos-header">
        <div>
          <h1>{t('pos.welcome')}</h1>
          <p>Store: {user?.name}</p>
        </div>
        <div className="pos-actions">
          <div className="sync-status">
            {isSyncing ? (
              <span className="sync-indicator syncing">⏳ Syncing...</span>
            ) : (
              <>
                <span className="sync-indicator">✓ Synced</span>
                {lastSync && (
                  <small>
                    {t('dashboard.lastSync')} {lastSync.toLocaleTimeString()}
                  </small>
                )}
              </>
            )}
          </div>
          <button className="btn btn-secondary btn-sm" onClick={syncNow}>
            {t('dashboard.syncStatus')}
          </button>
          <button className="btn btn-secondary" onClick={handleLogout}>
            {t('common.logout')}
          </button>
        </div>
      </div>

      <div className="pos-layout">
        {/* Products Section */}
        <div className="pos-products">
          <div className="search-bar">
            <input
              type="text"
              placeholder={t('pos.search')}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {loading ? (
            <div className="spinner"></div>
          ) : (
            <div className="products-grid">
              {filteredProducts.map((product) => (
                <div key={product.id} className="product-card">
                  <h4>{product.name_en}</h4>
                  {product.name_so && <small>{product.name_so}</small>}
                  {product.name_ar && <small>{product.name_ar}</small>}
                  <p className="price">${product.price.toFixed(2)}</p>
                  <p className="stock">
                    {product.quantity_in_stock > 0
                      ? `${t('pos.stock')}: ${product.quantity_in_stock}`
                      : t('pos.outOfStock')}
                  </p>
                  <button
                    className="btn btn-success btn-sm"
                    onClick={() => handleAddToCart(product)}
                    disabled={product.quantity_in_stock === 0}
                  >
                    {t('pos.addToCart')}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Cart Section */}
        <div className="pos-cart">
          <div className="cart-header">
            <h2>{t('pos.cart')}</h2>
            {cartStore.items.length > 0 && (
              <button
                className="btn btn-secondary btn-sm"
                onClick={() => cartStore.clear()}
              >
                Clear
              </button>
            )}
          </div>

          {cartStore.items.length === 0 ? (
            <p className="empty-cart">{t('common.noData')}</p>
          ) : (
            <>
              <div className="cart-items">
                {cartStore.items.map((item) => (
                  <div key={item.product_id} className="cart-item">
                    <div className="item-info">
                      <h4>{item.product_name}</h4>
                      <p>${item.unit_price.toFixed(2)}</p>
                    </div>
                    <div className="item-quantity">
                      <button
                        onClick={() =>
                          cartStore.updateQuantity(
                            item.product_id,
                            item.quantity - 1
                          )
                        }
                      >
                        −
                      </button>
                      <input
                        type="number"
                        min="1"
                        value={item.quantity}
                        onChange={(e) =>
                          cartStore.updateQuantity(
                            item.product_id,
                            parseInt(e.target.value)
                          )
                        }
                      />
                      <button
                        onClick={() =>
                          cartStore.updateQuantity(
                            item.product_id,
                            item.quantity + 1
                          )
                        }
                      >
                        +
                      </button>
                    </div>
                    <div className="item-total">
                      ${(item.unit_price * item.quantity).toFixed(2)}
                    </div>
                    <button
                      className="btn btn-danger btn-xs"
                      onClick={() => cartStore.removeItem(item.product_id)}
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>

              <div className="cart-summary">
                <div className="summary-row">
                  <span>Items:</span>
                  <span>{cartStore.items.reduce((sum, item) => sum + item.quantity, 0)}</span>
                </div>
                <div className="summary-row total">
                  <span>{t('pos.total')}:</span>
                  <span>${cartStore.total().toFixed(2)}</span>
                </div>
              </div>

              <button
                className="btn btn-primary"
                onClick={() => setShowCheckout(true)}
              >
                {t('pos.checkout')}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Checkout Modal */}
      {showCheckout && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3 className="modal-title">{t('pos.checkout')}</h3>
              <span
                className="modal-close"
                onClick={() => setShowCheckout(false)}
              >
                ×
              </span>
            </div>

            <form onSubmit={(e) => { e.preventDefault(); handleCheckout(); }}>
              <div className="form-group">
                <label>{t('pos.customerName')}</label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label>{t('pos.paymentMethod')}</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                >
                  <option value="cash">{t('pos.cash')}</option>
                  <option value="card">{t('pos.card')}</option>
                  <option value="mobile">{t('pos.mobile')}</option>
                </select>
              </div>

              <div className="checkout-summary">
                <div className="summary-row total">
                  <span>{t('pos.total')}:</span>
                  <span>${cartStore.total().toFixed(2)}</span>
                </div>
              </div>

              <button type="submit" className="btn btn-success">
                {t('pos.completeTransaction')}
              </button>
            </form>
          </div>
        </div>
      )}

      <style>{`
        .pos-container {
          padding: 1rem;
        }

        .pos-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 2rem;
          background: white;
          padding: 1.5rem;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .pos-header h1 {
          margin: 0;
          color: #2c3e50;
        }

        .pos-header p {
          margin: 0.5rem 0 0 0;
          color: #7f8c8d;
        }

        .pos-actions {
          display: flex;
          gap: 1rem;
          align-items: center;
        }

        .sync-status {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          font-size: 0.85rem;
        }

        .sync-indicator {
          padding: 0.25rem 0.5rem;
          border-radius: 4px;
          background-color: #d4edda;
          color: #155724;
        }

        .sync-indicator.syncing {
          background-color: #fff3cd;
          color: #856404;
        }

        .btn-sm {
          padding: 0.5rem 1rem;
          font-size: 0.9rem;
        }

        .pos-layout {
          display: grid;
          grid-template-columns: 1fr 350px;
          gap: 1.5rem;
        }

        @media (max-width: 1024px) {
          .pos-layout {
            grid-template-columns: 1fr;
          }
        }

        .pos-products {
          background: white;
          border-radius: 8px;
          padding: 1.5rem;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .search-bar {
          margin-bottom: 1.5rem;
        }

        .search-bar input {
          width: 100%;
          padding: 0.75rem;
          border: 1px solid #ddd;
          border-radius: 4px;
          font-size: 1rem;
        }

        .products-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
          gap: 1rem;
        }

        .product-card {
          border: 1px solid #ecf0f1;
          border-radius: 8px;
          padding: 1rem;
          text-align: center;
          transition: all 0.3s;
        }

        .product-card:hover {
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .product-card h4 {
          margin: 0 0 0.5rem 0;
          font-size: 0.95rem;
        }

        .product-card small {
          display: block;
          color: #7f8c8d;
          font-size: 0.8rem;
        }

        .product-card .price {
          font-size: 1.2rem;
          font-weight: bold;
          color: #27ae60;
          margin: 0.5rem 0;
        }

        .product-card .stock {
          font-size: 0.85rem;
          color: #7f8c8d;
          margin: 0.5rem 0;
        }

        .btn-xs {
          padding: 0.25rem 0.5rem;
          font-size: 0.75rem;
        }

        .pos-cart {
          background: white;
          border-radius: 8px;
          padding: 1.5rem;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
          display: flex;
          flex-direction: column;
          height: fit-content;
          position: sticky;
          top: 20px;
        }

        .cart-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1rem;
        }

        .cart-header h2 {
          margin: 0;
          font-size: 1.25rem;
        }

        .empty-cart {
          text-align: center;
          color: #7f8c8d;
          padding: 2rem 0;
        }

        .cart-items {
          flex: 1;
          overflow-y: auto;
          margin-bottom: 1rem;
          max-height: 400px;
        }

        .cart-item {
          display: flex;
          gap: 0.5rem;
          padding: 0.75rem;
          border-bottom: 1px solid #ecf0f1;
          align-items: center;
        }

        .item-info {
          flex: 1;
        }

        .item-info h4 {
          margin: 0;
          font-size: 0.9rem;
        }

        .item-info p {
          margin: 0.25rem 0 0 0;
          color: #7f8c8d;
          font-size: 0.85rem;
        }

        .item-quantity {
          display: flex;
          gap: 0.25rem;
        }

        .item-quantity button {
          padding: 0.25rem 0.5rem;
          border: 1px solid #ddd;
          background: white;
          cursor: pointer;
          border-radius: 2px;
        }

        .item-quantity input {
          width: 40px;
          text-align: center;
          border: 1px solid #ddd;
          padding: 0.25rem;
        }

        .item-total {
          font-weight: bold;
          min-width: 60px;
          text-align: right;
        }

        .cart-summary {
          border-top: 2px solid #ecf0f1;
          padding: 1rem 0;
          margin: 1rem 0;
        }

        .summary-row {
          display: flex;
          justify-content: space-between;
          margin-bottom: 0.5rem;
        }

        .summary-row.total {
          font-size: 1.1rem;
          font-weight: bold;
          color: #27ae60;
        }
      `}</style>
    </div>
  );
};

export default POSDashboard;
