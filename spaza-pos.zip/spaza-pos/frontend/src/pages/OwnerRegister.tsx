import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { authService } from '../services/api';
import { useAuthStore } from '../store';

const OwnerRegister = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const setAuth = useAuthStore((state) => state.setAuth);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    fullName: '',
    phone: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (formData.password !== formData.confirmPassword) {
      setError(t('errors.passwordMismatch'));
      return;
    }

    try {
      setLoading(true);
      const response = await authService.ownerRegister(
        formData.email,
        formData.password,
        formData.fullName,
        formData.phone
      );

      const { owner, token } = response.data;
      setAuth(token, owner, 'owner');
      navigate('/owner/dashboard');
    } catch (err: any) {
      setError(err.response?.data?.error || t('errors.registrationFailed'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container auth-container">
      <div className="auth-card">
        <h2>{t('common.register')}</h2>
        {error && <div className="alert alert-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>{t('common.email')}</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="form-group">
            <label>{t('owner.fullName') || 'Full Name'}</label>
            <input
              type="text"
              name="fullName"
              value={formData.fullName}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="form-group">
            <label>{t('owner.phone') || 'Phone'}</label>
            <input
              type="tel"
              name="phone"
              value={formData.phone}
              onChange={handleInputChange}
            />
          </div>

          <div className="form-group">
            <label>{t('common.password')}</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Confirm Password</label>
            <input
              type="password"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleInputChange}
              required
            />
          </div>

          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? t('common.loading') : t('common.register')}
          </button>
        </form>

        <p>
          Already have an account?{' '}
          <button
            type="button"
            className="link-btn"
            onClick={() => navigate('/owner/login')}
          >
            {t('common.login')}
          </button>
        </p>
        <p>
          Are you a store? {' '}
          <button
            type="button"
            className="link-btn"
            onClick={() => navigate('/store/login')}
          >
            {t('common.login')} as Store
          </button>
        </p>
      </div>
    </div>
  );
};

export default OwnerRegister;
