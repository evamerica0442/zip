import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ownerService } from '../services/api';
import { useAuthStore } from '../store';

const OwnerDashboard = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { logout, user } = useAuthStore();
  const [stores, setStores] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newStoreData, setNewStoreData] = useState({
    storeName: '',
    location: '',
    phone: '',
    email: '',
  });
  const [createdStore, setCreatedStore] = useState<any>(null);

  useEffect(() => {
    fetchStores();
  }, []);

  const fetchStores = async () => {
    try {
      setLoading(true);
      const response = await ownerService.getStores();
      setStores(response.data);
    } catch (error) {
      console.error('Failed to fetch stores:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateStore = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await ownerService.createStore(
        newStoreData.storeName,
        newStoreData.location,
        newStoreData.phone,
        newStoreData.email
      );

      setCreatedStore(response.data);
      setNewStoreData({ storeName: '', location: '', phone: '', email: '' });
      fetchStores();
    } catch (error) {
      console.error('Failed to create store:', error);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/owner/login');
  };

  return (
    <div className="container">
      <div className="header-section">
        <h1>{t('owner.welcome')}, {user?.full_name}!</h1>
        <button className="btn btn-secondary" onClick={handleLogout}>
          {t('common.logout')}
        </button>
      </div>

      <div className="stores-section">
        <div className="section-header">
          <h2>{t('owner.myStores')}</h2>
          <button
            className="btn btn-primary"
            onClick={() => setShowCreateModal(true)}
          >
            {t('owner.createStore')}
          </button>
        </div>

        {loading ? (
          <div className="spinner"></div>
        ) : stores.length === 0 ? (
          <div className="card">
            <p>{t('common.noData')}</p>
          </div>
        ) : (
          <div className="grid grid-2">
            {stores.map((store) => (
              <div key={store.id} className="card store-card">
                <h3>{store.store_name}</h3>
                <p>
                  <strong>Username:</strong> {store.store_username}
                </p>
                {store.location && (
                  <p>
                    <strong>{t('owner.location')}:</strong> {store.location}
                  </p>
                )}
                {store.phone && (
                  <p>
                    <strong>{t('owner.phone')}:</strong> {store.phone}
                  </p>
                )}
                <button
                  className="btn btn-primary"
                  onClick={() => navigate(`/owner/store/${store.id}`)}
                >
                  View Metrics
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Create Store Modal */}
      {showCreateModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3 className="modal-title">{t('owner.createStore')}</h3>
              <span className="modal-close" onClick={() => setShowCreateModal(false)}>
                ×
              </span>
            </div>

            {createdStore && (
              <div className="alert alert-success">
                <h4>Store Created Successfully!</h4>
                <p>
                  <strong>Username:</strong> {createdStore.credentials.username}
                </p>
                <p>
                  <strong>Password:</strong> {createdStore.credentials.password}
                </p>
                <p style={{ color: '#155724', marginTop: '1rem' }}>
                  ⚠️ {createdStore.credentials.message}
                </p>
                <button
                  className="btn btn-primary"
                  onClick={() => {
                    setCreatedStore(null);
                    setShowCreateModal(false);
                  }}
                >
                  {t('common.close')}
                </button>
              </div>
            )}

            {!createdStore && (
              <form onSubmit={handleCreateStore}>
                <div className="form-group">
                  <label>{t('owner.storeName')}</label>
                  <input
                    type="text"
                    value={newStoreData.storeName}
                    onChange={(e) =>
                      setNewStoreData({
                        ...newStoreData,
                        storeName: e.target.value,
                      })
                    }
                    required
                  />
                </div>

                <div className="form-group">
                  <label>{t('owner.location')}</label>
                  <input
                    type="text"
                    value={newStoreData.location}
                    onChange={(e) =>
                      setNewStoreData({
                        ...newStoreData,
                        location: e.target.value,
                      })
                    }
                  />
                </div>

                <div className="form-group">
                  <label>{t('owner.phone')}</label>
                  <input
                    type="tel"
                    value={newStoreData.phone}
                    onChange={(e) =>
                      setNewStoreData({
                        ...newStoreData,
                        phone: e.target.value,
                      })
                    }
                  />
                </div>

                <div className="form-group">
                  <label>{t('common.email')}</label>
                  <input
                    type="email"
                    value={newStoreData.email}
                    onChange={(e) =>
                      setNewStoreData({
                        ...newStoreData,
                        email: e.target.value,
                      })
                    }
                  />
                </div>

                <button type="submit" className="btn btn-primary">
                  {t('owner.createStore')}
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      <style>{`
        .header-section {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 2rem;
        }

        .section-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1.5rem;
        }

        .store-card {
          display: flex;
          flex-direction: column;
        }

        .store-card h3 {
          margin-bottom: 1rem;
          color: #2c3e50;
        }

        .store-card p {
          margin-bottom: 0.5rem;
          font-size: 0.9rem;
        }

        .store-card button {
          margin-top: auto;
        }

        .link-btn {
          background: none;
          border: none;
          color: #3498db;
          cursor: pointer;
          text-decoration: underline;
          font-size: inherit;
        }

        .link-btn:hover {
          color: #2980b9;
        }

        .auth-container {
          display: flex;
          justify-content: center;
          align-items: center;
          min-height: 80vh;
        }

        .auth-card {
          background: white;
          padding: 2rem;
          border-radius: 8px;
          width: 100%;
          max-width: 400px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .auth-card h2 {
          margin-bottom: 1.5rem;
          text-align: center;
        }

        .auth-card form {
          margin-bottom: 1.5rem;
        }

        .auth-card p {
          text-align: center;
          margin-top: 1rem;
        }

        .language-selector {
          padding: 0.5rem;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-size: 0.95rem;
        }
      `}</style>
    </div>
  );
};

export default OwnerDashboard;
