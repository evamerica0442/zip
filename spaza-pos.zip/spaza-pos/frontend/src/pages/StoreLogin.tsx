import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { authService } from '../services/api';
import { useAuthStore } from '../store';

const StoreLogin = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const setAuth = useAuthStore((state) => state.setAuth);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      setLoading(true);
      const response = await authService.storeLogin(formData.username, formData.password);
      const { store, token } = response.data;
      setAuth(token, store, 'store');
      navigate('/store/pos');
    } catch (err: any) {
      setError(err.response?.data?.error || t('errors.loginFailed'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container auth-container">
      <div className="auth-card">
        <h2>{t('pos.welcome')}</h2>
        {error && <div className="alert alert-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>{t('owner.username')}</label>
            <input
              type="text"
              name="username"
              value={formData.username}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="form-group">
            <label>{t('common.password')}</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleInputChange}
              required
            />
          </div>

          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? t('common.loading') : t('common.login')}
          </button>
        </form>

        <p>
          Are you an owner?{' '}
          <button
            type="button"
            className="link-btn"
            onClick={() => navigate('/owner/login')}
          >
            {t('common.login')} as Owner
          </button>
        </p>
      </div>

      <style>{`
        .auth-container {
          display: flex;
          justify-content: center;
          align-items: center;
          min-height: 80vh;
        }

        .auth-card {
          background: white;
          padding: 2rem;
          border-radius: 8px;
          width: 100%;
          max-width: 400px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .auth-card h2 {
          margin-bottom: 1.5rem;
          text-align: center;
        }

        .auth-card form {
          margin-bottom: 1.5rem;
        }

        .auth-card p {
          text-align: center;
          margin-top: 1rem;
        }

        .link-btn {
          background: none;
          border: none;
          color: #3498db;
          cursor: pointer;
          text-decoration: underline;
          font-size: inherit;
        }

        .link-btn:hover {
          color: #2980b9;
        }
      `}</style>
    </div>
  );
};

export default StoreLogin;
