import { useEffect, useState } from 'react';
import { transactionService } from '../services/api';
import { db } from '../services/database';

export const useSyncTransactions = () => {
  const [lastSync, setLastSync] = useState<Date | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);

  useEffect(() => {
    // Sync pending transactions every 30 minutes
    const syncInterval = setInterval(syncPendingTransactions, 30 * 60 * 1000);

    // Try to sync immediately on load if there are pending transactions
    syncPendingTransactions();

    return () => clearInterval(syncInterval);
  }, []);

  const syncPendingTransactions = async () => {
    try {
      setIsSyncing(true);
      const pendingTransactions = await db.transactions.where('synced').equals(false).toArray();

      if (pendingTransactions.length > 0) {
        await transactionService.syncTransactions(pendingTransactions);

        // Mark as synced locally
        await Promise.all(
          pendingTransactions.map((tx) =>
            db.transactions.update(tx.id!, { synced: true })
          )
        );

        setLastSync(new Date());
      }
    } catch (error) {
      console.error('Sync failed:', error);
    } finally {
      setIsSyncing(false);
    }
  };

  return { lastSync, isSyncing, syncNow: syncPendingTransactions };
};
