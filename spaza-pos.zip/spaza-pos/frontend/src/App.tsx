import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuthStore } from './store';
import LanguageSwitcher from './components/LanguageSwitcher';
import OwnerLogin from './pages/OwnerLogin';
import OwnerRegister from './pages/OwnerRegister';
import OwnerDashboard from './pages/OwnerDashboard';
import StoreLogin from './pages/StoreLogin';
import POSDashboard from './pages/POSDashboard';
import './App.css';

function App() {
  const { t } = useTranslation();
  const { token, userType } = useAuthStore();

  return (
    <Router>
      <div className="app">
        <nav className="navbar">
          <div className="navbar-container">
            <div className="navbar-brand">
              <h1>{t('app.title')}</h1>
            </div>
            <LanguageSwitcher />
          </div>
        </nav>

        <Routes>
          {/* Owner Routes */}
          <Route path="/owner/register" element={<OwnerRegister />} />
          <Route path="/owner/login" element={<OwnerLogin />} />
          <Route
            path="/owner/dashboard"
            element={token && userType === 'owner' ? <OwnerDashboard /> : <Navigate to="/owner/login" />}
          />

          {/* Store Routes */}
          <Route path="/store/login" element={<StoreLogin />} />
          <Route
            path="/store/pos"
            element={token && userType === 'store' ? <POSDashboard /> : <Navigate to="/store/login" />}
          />

          {/* Default redirect */}
          <Route path="/" element={<Navigate to="/owner/login" />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
