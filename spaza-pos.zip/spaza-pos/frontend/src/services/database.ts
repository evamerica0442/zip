import Dexie, { Table } from 'dexie';

export interface Product {
  id?: string;
  sku: string;
  name_en: string;
  name_so?: string;
  name_ar?: string;
  category?: string;
  price: number;
  quantity_in_stock: number;
}

export interface Transaction {
  id?: string;
  transaction_date: Date;
  items: {
    product_id: string;
    product_name: string;
    quantity: number;
    unit_price: number;
    total: number;
  }[];
  total_amount: number;
  payment_method?: string;
  customer_name?: string;
  synced: boolean;
}

export class POSDatabase extends Dexie {
  products!: Table<Product>;
  transactions!: Table<Transaction>;

  constructor() {
    super('POSDatabase');
    this.version(1).stores({
      products: 'sku',
      transactions: '++id, synced, transaction_date',
    });
  }
}

export const db = new POSDatabase();
