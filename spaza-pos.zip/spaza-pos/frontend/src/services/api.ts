import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:5000/api';

const apiClient = axios.create({
  baseURL: API_BASE_URL,
});

// Add token to requests
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const authService = {
  ownerRegister: (email: string, password: string, fullName: string, phone?: string, preferredLanguage?: string) =>
    apiClient.post('/auth/owner/register', {
      email,
      password,
      fullName,
      phone,
      preferredLanguage,
    }),

  ownerLogin: (email: string, password: string) =>
    apiClient.post('/auth/owner/login', { email, password }),

  storeLogin: (username: string, password: string) =>
    apiClient.post('/auth/store/login', { username, password }),
};

export const ownerService = {
  getStores: () => apiClient.get('/owner/stores'),
  createStore: (storeName: string, location?: string, phone?: string, email?: string) =>
    apiClient.post('/owner/stores', { storeName, location, phone, email }),
  getMetrics: (storeId: string) => apiClient.get(`/owner/metrics/${storeId}`),
};

export const storeService = {
  getProducts: () => apiClient.get('/store/products'),
  addProduct: (sku: string, nameEn: string, nameSo?: string, nameAr?: string, category?: string, price?: number, reorderLevel?: number) =>
    apiClient.post('/store/products', { sku, nameEn, nameSo, nameAr, category, price, reorderLevel }),
  getStoreInfo: () => apiClient.get('/store/info'),
};

export const transactionService = {
  syncTransactions: (transactions: any[]) =>
    apiClient.post('/transactions/sync', { transactions }),
  getPendingTransactions: () => apiClient.get('/transactions/pending'),
};

export default apiClient;
