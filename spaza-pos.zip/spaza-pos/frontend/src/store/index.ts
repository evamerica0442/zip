import { create } from 'zustand';

interface AuthStore {
  token: string | null;
  user: any;
  userType: 'owner' | 'store' | null;
  setAuth: (token: string, user: any, userType: 'owner' | 'store') => void;
  logout: () => void;
}

export const useAuthStore = create<AuthStore>((set) => ({
  token: localStorage.getItem('token'),
  user: JSON.parse(localStorage.getItem('user') || '{}'),
  userType: (localStorage.getItem('userType') as any) || null,

  setAuth: (token: string, user: any, userType: 'owner' | 'store') => {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    localStorage.setItem('userType', userType);
    set({ token, user, userType });
  },

  logout: () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem('userType');
    set({ token: null, user: null, userType: null });
  },
}));

interface CartItem {
  product_id: string;
  product_name: string;
  quantity: number;
  unit_price: number;
}

interface CartStore {
  items: CartItem[];
  addItem: (item: CartItem) => void;
  removeItem: (product_id: string) => void;
  updateQuantity: (product_id: string, quantity: number) => void;
  clear: () => void;
  total: () => number;
}

export const useCartStore = create<CartStore>((set, get) => ({
  items: [],

  addItem: (item: CartItem) => {
    set((state) => {
      const existing = state.items.find((i) => i.product_id === item.product_id);
      if (existing) {
        return {
          items: state.items.map((i) =>
            i.product_id === item.product_id ? { ...i, quantity: i.quantity + item.quantity } : i
          ),
        };
      }
      return { items: [...state.items, item] };
    });
  },

  removeItem: (product_id: string) => {
    set((state) => ({
      items: state.items.filter((i) => i.product_id !== product_id),
    }));
  },

  updateQuantity: (product_id: string, quantity: number) => {
    if (quantity <= 0) {
      get().removeItem(product_id);
      return;
    }
    set((state) => ({
      items: state.items.map((i) => (i.product_id === product_id ? { ...i, quantity } : i)),
    }));
  },

  clear: () => set({ items: [] }),

  total: () => {
    return get().items.reduce((sum, item) => sum + item.unit_price * item.quantity, 0);
  },
}));
