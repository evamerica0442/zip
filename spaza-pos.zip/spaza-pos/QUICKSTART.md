# Quick Start Guide - Spaza Shop POS

## 📦 Prerequisites

- Node.js 16+ (download from nodejs.org)
- PostgreSQL 12+ (download from postgresql.org)
- Git (for version control)
- A modern web browser

## ⚡ 5-Minute Setup

### Step 1: Clone the Project
```bash
cd path/to/your/workspace
git clone <repository-url>
cd spaza-pos
```

### Step 2: Install Dependencies
```bash
# Install all dependencies
npm install
npm install --workspace=backend
npm install --workspace=frontend
```

### Step 3: Set Up Database
```bash
# Create PostgreSQL database (using psql)
psql -U postgres
CREATE DATABASE spaza_pos;
\q

# Or using pgAdmin GUI
# 1. Right-click Databases
# 2. Create > Database
# 3. Name it "spaza_pos"
```

### Step 4: Configure Environment

**Backend (.env)**
```bash
cd backend
cp .env.example .env
# Edit .env with your PostgreSQL credentials
```

**Frontend (.env)**
```bash
cd ../frontend
cp .env.example .env
# Leave as default if running locally
```

### Step 5: Initialize Database
```bash
cd ../backend
npm run migrate
```

### Step 6: Start Development Servers

**Terminal 1 - Backend:**
```bash
cd backend
npm run dev
# Server runs on http://localhost:5000
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm run dev
# App opens on http://localhost:3000
```

## 🎯 First Steps in the App

### As an Owner:
1. Go to http://localhost:3000
2. Click "Register" 
3. Create owner account
4. Create a store (credentials auto-generated)
5. Share store username/password with staff

### As Store Staff:
1. Go to http://localhost:3000/store/login
2. Login with store credentials
3. Add products (with multi-language names)
4. Ring up sales
5. Complete transactions
6. Works offline and syncs automatically

## 🧪 Test Data (Optional)

### Quick Test Flow:
```bash
# Terminal: Test API endpoints
curl http://localhost:5000/health

# Login test
curl -X POST http://localhost:5000/api/auth/owner/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

## 🔗 Useful Links

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:5000
- **API Docs**: See /API.md
- **Database**: psql -U postgres -d spaza_pos

## 📚 File Locations

```
spaza-pos/
├── backend/          - Express API server
├── frontend/         - React web app
├── README.md         - Project overview
├── API.md            - API documentation
├── DATABASE.md       - Database setup guide
├── DEVELOPMENT.md    - Development guide
└── DEPLOYMENT.md     - Production deployment
```

## 🚨 Common Issues & Solutions

### "Cannot find module" Error
```bash
# Run this in the affected folder
npm install
```

### PostgreSQL Connection Error
```bash
# Windows: Start PostgreSQL service
net start postgresql-x64-15

# macOS: Start with Homebrew
brew services start postgresql

# Linux: Start with systemctl
sudo systemctl start postgresql
```

### Port Already in Use
```bash
# Kill process on port 5000 (macOS/Linux)
lsof -i :5000 | grep LISTEN | awk '{print $2}' | xargs kill -9

# Kill process on port 5000 (Windows)
netstat -ano | findstr :5000
taskkill /PID <PID> /F
```

### Database Not Found
```bash
# Check if database exists
psql -U postgres -l | grep spaza_pos

# Create if missing
psql -U postgres -c "CREATE DATABASE spaza_pos;"
```

## 🌍 Language Support

Switch languages in the top right of the app:
- **English** - Default, full support
- **Somali** - Community-focused
- **العربية** (Arabic) - Full RTL support

## 💾 Offline Testing

1. **Network offline in DevTools** (F12 > Network > Offline)
2. **Add products** while online
3. **Go offline** and create transactions
4. **Go back online** - auto-syncs in 30 seconds

## 📞 Testing Multi-Owner Setup

1. Register **Owner A**, create Store 1
2. Register **Owner B**, create Store 2
3. Each owner only sees their own stores
4. Products isolated per store

## 🔐 Security Notes

- Change `JWT_SECRET` in production (.env file)
- Use strong passwords
- Never commit `.env` files
- Enable HTTPS in production
- Use environment variables for secrets

## 📈 Next Steps

1. ✅ Run the application
2. ✅ Test owner registration and store creation
3. ✅ Test POS (add products, create transactions)
4. ✅ Test offline mode and sync
5. ✅ View metrics in owner dashboard
6. ✅ Try different languages

For detailed docs, see DEVELOPMENT.md

## 🆘 Need Help?

Check these documents:
- **Setup issues**: DEVELOPMENT.md
- **Database questions**: DATABASE.md  
- **Deployment**: DEPLOYMENT.md
- **API details**: API.md
- **Project status**: .github/PROJECT_STATUS.md

## 🎉 You're Ready!

Your Spaza Shop POS system is now running. Start by:
1. Creating an owner account
2. Adding a store
3. Creating some test products
4. Processing a sample transaction

Happy selling! 🛍️
