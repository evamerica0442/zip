# Deployment Guide

## Environment Setup

### Production Environment Variables

#### Backend (.env)
```env
DB_HOST=your-prod-db-host
DB_PORT=5432
DB_NAME=spaza_pos
DB_USER=prod_user
DB_PASSWORD=strong_password_here
JWT_SECRET=very_long_random_secret_key_at_least_32_chars
NODE_ENV=production
PORT=5000
SYNC_INTERVAL=1800000
```

#### Frontend (.env.production)
```env
REACT_APP_API_BASE_URL=https://api.yourdomain.com/api
```

## Docker Deployment

### Backend Dockerfile
Create `backend/Dockerfile`:
```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY src src
COPY tsconfig.json .

RUN npm run build

EXPOSE 5000

CMD ["npm", "start"]
```

### Frontend Dockerfile
Create `frontend/Dockerfile`:
```dockerfile
FROM node:18-alpine as builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/build /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

### Docker Compose
Create `docker-compose.yml`:
```yaml
version: '3.8'

services:
  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: spaza_pos
      POSTGRES_USER: spaza_user
      POSTGRES_PASSWORD: secure_password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  backend:
    build: ./backend
    environment:
      DB_HOST: postgres
      DB_PORT: 5432
      DB_NAME: spaza_pos
      DB_USER: spaza_user
      DB_PASSWORD: secure_password
      JWT_SECRET: your_secret_key
      NODE_ENV: production
    depends_on:
      - postgres
    ports:
      - "5000:5000"

  frontend:
    build: ./frontend
    environment:
      REACT_APP_API_BASE_URL: http://localhost:5000/api
    ports:
      - "80:80"
    depends_on:
      - backend

volumes:
  postgres_data:
```

## Cloud Deployment Options

### 1. Heroku

#### Backend
```bash
cd backend

# Login to Heroku
heroku login

# Create app
heroku create spaza-pos-api

# Add PostgreSQL
heroku addons:create heroku-postgresql:standard-0 --app spaza-pos-api

# Set environment variables
heroku config:set JWT_SECRET=your_secret --app spaza-pos-api
heroku config:set NODE_ENV=production --app spaza-pos-api

# Deploy
git push heroku main
```

#### Frontend
Deploy to Vercel or Netlify instead. Update API URL after backend deployment.

### 2. Railway

1. Sign up at railway.app
2. Connect GitHub repository
3. Select backend directory
4. Add PostgreSQL plugin
5. Set environment variables
6. Deploy

### 3. AWS Deployment

#### EC2 + RDS
- Launch EC2 instance (Node.js with PM2)
- Create RDS PostgreSQL database
- Deploy frontend to S3 + CloudFront
- Configure security groups

#### ECS + RDS
- Create ECS cluster
- Deploy backend as container service
- Create RDS PostgreSQL database
- Deploy frontend to S3 + CloudFront

### 4. Google Cloud / Azure

Follow similar cloud-native deployment patterns with their managed database services.

## Security Checklist

- [ ] Use HTTPS/TLS in production
- [ ] Set strong JWT_SECRET (min 32 characters)
- [ ] Enable CORS for frontend domain only
- [ ] Set secure database credentials
- [ ] Enable database backups
- [ ] Configure firewall rules
- [ ] Use environment variables for secrets
- [ ] Implement rate limiting
- [ ] Set up monitoring and logging
- [ ] Implement database encryption
- [ ] Use persistent volumes for data

## Monitoring & Logging

### Backend Logging
```typescript
// Add logging to index.ts
import winston from 'winston';

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' })
  ]
});
```

### Database Backups

Daily automated backups:
```bash
# Add to crontab
0 2 * * * pg_dump -U spaza_user spaza_pos > /backups/spaza_pos_$(date +\%Y\%m\%d).sql
```

## Performance Optimization

### Frontend
- Enable gzip compression
- Minify and bundle assets
- Use CDN for static files
- Implement lazy loading
- Cache service workers

### Backend
- Enable query result caching
- Use connection pooling
- Implement API rate limiting
- Add database indexes
- Monitor slow queries

## Health Checks

Add health endpoint checks:
```bash
# Health check endpoint
curl https://api.yourdomain.com/health

# Database connectivity
curl https://api.yourdomain.com/api/health
```

## Scaling Recommendations

- **Small**: Single server + managed database
- **Medium**: Load balanced API + managed database + CDN
- **Large**: Kubernetes cluster + managed database + cache layer

## Rollback Plan

1. Keep previous version tagged in git
2. Document database migrations
3. Plan rollback procedure
4. Test recovery process
5. Keep database backups at multiple locations
